import { User, ChatRoom, ChatMessage, ChatRoomType } from '../types';

// Generate different chat rooms based on user role
export const generateDummyChatRooms = (currentUser: User): ChatRoom[] => {
  const rooms: ChatRoom[] = [];
  
  if (currentUser.role === 'Buyer') {
    // Buyers can chat with Sellers
    rooms.push({
      id: 'room-1',
      type: 'BuyerSeller',
      buyerId: currentUser.id,
      sellerId: 'seller-1',
      unreadCount: 2,
      updatedAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      otherUser: { id: 'seller-1', name: 'Mary Seller', role: 'Seller', avatar: 'https://i.pravatar.cc/150?img=5' },
      lastMessage: {
        id: 'msg-last-1',
        chatRoomId: 'room-1',
        senderId: 'seller-1',
        message: 'Yes, the car is still available for test drive',
        isRead: false,
        status: 'Delivered',
        sentAt: new Date(Date.now() - 1000 * 60 * 30)
      }
    });
    
    rooms.push({
      id: 'room-2',
      type: 'BuyerSeller',
      buyerId: currentUser.id,
      sellerId: 'seller-2',
      unreadCount: 0,
      updatedAt: new Date(Date.now() - 1000 * 60 * 120), // 2 hours ago
      otherUser: { id: 'seller-2', name: 'Tom Seller', role: 'Seller', avatar: 'https://i.pravatar.cc/150?img=8' },
      lastMessage: {
        id: 'msg-last-2',
        chatRoomId: 'room-2',
        senderId: currentUser.id,
        message: 'Thanks for the information about the sedan',
        isRead: true,
        status: 'Seen',
        sentAt: new Date(Date.now() - 1000 * 60 * 120)
      }
    });
    
    // Buyers can also chat with Admin
    rooms.push({
      id: 'room-admin',
      type: 'UserAdmin',
      userId: currentUser.id,
      adminId: 'admin-1',
      unreadCount: 1,
      updatedAt: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
      otherUser: { id: 'admin-1', name: 'Support Team', role: 'Admin', avatar: 'https://i.pravatar.cc/150?img=1' },
      lastMessage: {
        id: 'msg-last-admin',
        chatRoomId: 'room-admin',
        senderId: 'admin-1',
        message: 'How can we help you today?',
        isRead: false,
        status: 'Delivered',
        sentAt: new Date(Date.now() - 1000 * 60 * 5)
      }
    });
  } 
  else if (currentUser.role === 'Seller') {
    // Sellers can chat with Buyers
    rooms.push({
      id: 'room-1',
      type: 'BuyerSeller',
      sellerId: currentUser.id,
      buyerId: 'buyer-1',
      unreadCount: 0,
      updatedAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      otherUser: { id: 'buyer-1', name: 'John Buyer', role: 'Buyer', avatar: 'https://i.pravatar.cc/150?img=4' },
      lastMessage: {
        id: 'msg-last-1',
        chatRoomId: 'room-1',
        senderId: 'seller-1',
        message: 'Yes, the car is still available for test drive',
        isRead: true,
        status: 'Delivered',
        sentAt: new Date(Date.now() - 1000 * 60 * 30)
      }
    });
    
    rooms.push({
      id: 'room-3',
      type: 'BuyerSeller',
      sellerId: currentUser.id,
      buyerId: 'buyer-3',
      unreadCount: 3,
      updatedAt: new Date(Date.now() - 1000 * 60 * 10), // 10 minutes ago
      otherUser: { id: 'buyer-3', name: 'Emily Buyer', role: 'Buyer', avatar: 'https://i.pravatar.cc/150?img=6' },
      lastMessage: {
        id: 'msg-last-3',
        chatRoomId: 'room-3',
        senderId: 'buyer-3',
        message: 'What is the lowest price you can offer?',
        isRead: false,
        status: 'Delivered',
        sentAt: new Date(Date.now() - 1000 * 60 * 10)
      }
    });
    
    // Sellers can also chat with Admin
    rooms.push({
      id: 'room-admin',
      type: 'UserAdmin',
      userId: currentUser.id,
      adminId: 'admin-1',
      unreadCount: 0,
      updatedAt: new Date(Date.now() - 1000 * 60 * 1440), // 1 day ago
      otherUser: { id: 'admin-1', name: 'Support Team', role: 'Admin', avatar: 'https://i.pravatar.cc/150?img=1' },
      lastMessage: {
        id: 'msg-last-admin',
        chatRoomId: 'room-admin',
        senderId: currentUser.id,
        message: 'Thank you for your help',
        isRead: true,
        status: 'Seen',
        sentAt: new Date(Date.now() - 1000 * 60 * 1440)
      }
    });
  } 
  else if (currentUser.role === 'Car Owner') {
    // Car Owners can chat with Service Providers
    rooms.push({
      id: 'room-4',
      type: 'OwnerProvider',
      ownerId: currentUser.id,
      providerId: 'provider-1',
      unreadCount: 1,
      updatedAt: new Date(Date.now() - 1000 * 60 * 45), // 45 minutes ago
      otherUser: { id: 'provider-1', name: 'Sarah Provider', role: 'Service Provider', avatar: 'https://i.pravatar.cc/150?img=9' },
      lastMessage: {
        id: 'msg-last-4',
        chatRoomId: 'room-4',
        senderId: 'provider-1',
        message: 'Your appointment is confirmed for tomorrow at 2 PM',
        isRead: false,
        status: 'Delivered',
        sentAt: new Date(Date.now() - 1000 * 60 * 45)
      }
    });
    
    rooms.push({
      id: 'room-5',
      type: 'OwnerProvider',
      ownerId: currentUser.id,
      providerId: 'provider-2',
      unreadCount: 0,
      updatedAt: new Date(Date.now() - 1000 * 60 * 180), // 3 hours ago
      otherUser: { id: 'provider-2', name: 'Mike Provider', role: 'Service Provider', avatar: 'https://i.pravatar.cc/150?img=11' },
      lastMessage: {
        id: 'msg-last-5',
        chatRoomId: 'room-5',
        senderId: currentUser.id,
        message: 'Do you offer brake pad replacement services?',
        isRead: true,
        status: 'Seen',
        sentAt: new Date(Date.now() - 1000 * 60 * 180)
      }
    });
    
    // Car Owners can also chat with Admin
    rooms.push({
      id: 'room-admin',
      type: 'UserAdmin',
      userId: currentUser.id,
      adminId: 'admin-1',
      unreadCount: 0,
      updatedAt: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      otherUser: { id: 'admin-1', name: 'Support Team', role: 'Admin', avatar: 'https://i.pravatar.cc/150?img=1' },
      lastMessage: {
        id: 'msg-last-admin',
        chatRoomId: 'room-admin',
        senderId: 'admin-1',
        message: 'We have resolved your issue with the booking system',
        isRead: true,
        status: 'Seen',
        sentAt: new Date(Date.now() - 1000 * 60 * 60)
      }
    });
  } 
  else if (currentUser.role === 'Service Provider') {
    // Service Providers can chat with Car Owners
    rooms.push({
      id: 'room-4',
      type: 'OwnerProvider',
      providerId: currentUser.id,
      ownerId: 'owner-1',
      unreadCount: 0,
      updatedAt: new Date(Date.now() - 1000 * 60 * 45), // 45 minutes ago
      otherUser: { id: 'owner-1', name: 'David Owner', role: 'Car Owner', avatar: 'https://i.pravatar.cc/150?img=3' },
      lastMessage: {
        id: 'msg-last-4',
        chatRoomId: 'room-4',
        senderId: 'provider-1',
        message: 'Your appointment is confirmed for tomorrow at 2 PM',
        isRead: true,
        status: 'Delivered',
        sentAt: new Date(Date.now() - 1000 * 60 * 45)
      }
    });
    
    rooms.push({
      id: 'room-6',
      type: 'OwnerProvider',
      providerId: currentUser.id,
      ownerId: 'owner-3',
      unreadCount: 2,
      updatedAt: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
      otherUser: { id: 'owner-3', name: 'Lisa Owner', role: 'Car Owner', avatar: 'https://i.pravatar.cc/150?img=7' },
      lastMessage: {
        id: 'msg-last-6',
        chatRoomId: 'room-6',
        senderId: 'owner-3',
        message: 'Can I reschedule my oil change appointment?',
        isRead: false,
        status: 'Delivered',
        sentAt: new Date(Date.now() - 1000 * 60 * 15)
      }
    });
    
    // Service Providers can also chat with Admin
    rooms.push({
      id: 'room-admin',
      type: 'UserAdmin',
      userId: currentUser.id,
      adminId: 'admin-1',
      unreadCount: 0,
      updatedAt: new Date(Date.now() - 1000 * 60 * 360), // 6 hours ago
      otherUser: { id: 'admin-1', name: 'Support Team', role: 'Admin', avatar: 'https://i.pravatar.cc/150?img=1' },
      lastMessage: {
        id: 'msg-last-admin',
        chatRoomId: 'room-admin',
        senderId: currentUser.id,
        message: 'When will the new service categories be available?',
        isRead: true,
        status: 'Seen',
        sentAt: new Date(Date.now() - 1000 * 60 * 360)
      }
    });
  } 
  else if (currentUser.role === 'Admin') {
    // Admin can chat with any user
    rooms.push({
      id: 'room-admin-buyer',
      type: 'UserAdmin',
      adminId: currentUser.id,
      userId: 'buyer-1',
      unreadCount: 0,
      updatedAt: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
      otherUser: { id: 'buyer-1', name: 'John Buyer', role: 'Buyer', avatar: 'https://i.pravatar.cc/150?img=4' },
      lastMessage: {
        id: 'msg-last-admin-buyer',
        chatRoomId: 'room-admin-buyer',
        senderId: 'admin-1',
        message: 'How can we help you today?',
        isRead: true,
        status: 'Delivered',
        sentAt: new Date(Date.now() - 1000 * 60 * 5)
      }
    });
    
    rooms.push({
      id: 'room-admin-seller',
      type: 'UserAdmin',
      adminId: currentUser.id,
      userId: 'seller-1',
      unreadCount: 0,
      updatedAt: new Date(Date.now() - 1000 * 60 * 1440), // 1 day ago
      otherUser: { id: 'seller-1', name: 'Mary Seller', role: 'Seller', avatar: 'https://i.pravatar.cc/150?img=5' },
      lastMessage: {
        id: 'msg-last-admin-seller',
        chatRoomId: 'room-admin-seller',
        senderId: 'seller-1',
        message: 'Thank you for your help',
        isRead: true,
        status: 'Seen',
        sentAt: new Date(Date.now() - 1000 * 60 * 1440)
      }
    });
    
    rooms.push({
      id: 'room-admin-owner',
      type: 'UserAdmin',
      adminId: currentUser.id,
      userId: 'owner-1',
      unreadCount: 0,
      updatedAt: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      otherUser: { id: 'owner-1', name: 'David Owner', role: 'Car Owner', avatar: 'https://i.pravatar.cc/150?img=3' },
      lastMessage: {
        id: 'msg-last-admin-owner',
        chatRoomId: 'room-admin-owner',
        senderId: 'admin-1',
        message: 'We have resolved your issue with the booking system',
        isRead: true,
        status: 'Seen',
        sentAt: new Date(Date.now() - 1000 * 60 * 60)
      }
    });
    
    rooms.push({
      id: 'room-admin-provider',
      type: 'UserAdmin',
      adminId: currentUser.id,
      userId: 'provider-1',
      unreadCount: 1,
      updatedAt: new Date(Date.now() - 1000 * 60 * 360), // 6 hours ago
      otherUser: { id: 'provider-1', name: 'Sarah Provider', role: 'Service Provider', avatar: 'https://i.pravatar.cc/150?img=9' },
      lastMessage: {
        id: 'msg-last-admin-provider',
        chatRoomId: 'room-admin-provider',
        senderId: 'provider-1',
        message: 'When will the new service categories be available?',
        isRead: false,
        status: 'Delivered',
        sentAt: new Date(Date.now() - 1000 * 60 * 360)
      }
    });
  }
  
  // Sort rooms by last message time
  return rooms.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
};

// Generate dummy messages for a specific chat room
export const generateDummyMessages = (room: ChatRoom, currentUser: User): ChatMessage[] => {
  const messages: ChatMessage[] = [];
  const otherUserId = room.otherUser.id;
  
  // Base time is 2 hours ago
  const baseTime = Date.now() - 1000 * 60 * 120;
  
  // Generate a conversation based on room type
  if (room.type === 'BuyerSeller') {
    // First message from buyer
    messages.push({
      id: `${room.id}-msg-1`,
      chatRoomId: room.id,
      senderId: room.buyerId as string,
      message: 'Hi, I\'m interested in your listing. Is it still available?',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime)
    });
    
    // Reply from seller
    messages.push({
      id: `${room.id}-msg-2`,
      chatRoomId: room.id,
      senderId: room.sellerId as string,
      message: 'Yes, it\'s still available. Would you like to schedule a viewing?',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime + 1000 * 60 * 10) // 10 minutes later
    });
    
    // Another message from buyer
    messages.push({
      id: `${room.id}-msg-3`,
      chatRoomId: room.id,
      senderId: room.buyerId as string,
      message: 'Great! Can I come see it tomorrow?',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime + 1000 * 60 * 20) // 20 minutes later
    });
    
    // Another reply from seller
    messages.push({
      id: `${room.id}-msg-4`,
      chatRoomId: room.id,
      senderId: room.sellerId as string,
      message: 'Tomorrow works. How about 3 PM?',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime + 1000 * 60 * 30) // 30 minutes later
    });
    
    // Confirmation from buyer
    messages.push({
      id: `${room.id}-msg-5`,
      chatRoomId: room.id,
      senderId: room.buyerId as string,
      message: 'Perfect! I\'ll see you at 3 PM. Can you provide the address?',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime + 1000 * 60 * 40) // 40 minutes later
    });
    
    // Last message
    if (room.lastMessage) {
      messages.push({
        id: room.lastMessage.id,
        chatRoomId: room.id,
        senderId: room.lastMessage.senderId,
        message: room.lastMessage.message,
        isRead: room.lastMessage.isRead,
        status: room.lastMessage.status,
        sentAt: room.lastMessage.sentAt
      });
    }
  } 
  else if (room.type === 'OwnerProvider') {
    // First message from owner
    messages.push({
      id: `${room.id}-msg-1`,
      chatRoomId: room.id,
      senderId: room.ownerId as string,
      message: 'Hello, I need to service my car. What are your available appointment slots?',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime)
    });
    
    // Reply from provider
    messages.push({
      id: `${room.id}-msg-2`,
      chatRoomId: room.id,
      senderId: room.providerId as string,
      message: 'We have slots available next Tuesday and Thursday. What time works for you?',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime + 1000 * 60 * 15) // 15 minutes later
    });
    
    // Response from owner
    messages.push({
      id: `${room.id}-msg-3`,
      chatRoomId: room.id,
      senderId: room.ownerId as string,
      message: 'Thursday would be perfect. Do you have anything in the afternoon?',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime + 1000 * 60 * 25) // 25 minutes later
    });
    
    // Confirmation from provider
    messages.push({
      id: `${room.id}-msg-4`,
      chatRoomId: room.id,
      senderId: room.providerId as string,
      message: 'Yes, we have 2 PM and 4 PM slots open on Thursday.',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime + 1000 * 60 * 35) // 35 minutes later
    });
    
    // Last message
    if (room.lastMessage) {
      messages.push({
        id: room.lastMessage.id,
        chatRoomId: room.id,
        senderId: room.lastMessage.senderId,
        message: room.lastMessage.message,
        isRead: room.lastMessage.isRead,
        status: room.lastMessage.status,
        sentAt: room.lastMessage.sentAt
      });
    }
  } 
  else if (room.type === 'UserAdmin') {
    // First message from user
    messages.push({
      id: `${room.id}-msg-1`,
      chatRoomId: room.id,
      senderId: room.userId as string,
      message: 'Hi support, I have a question about how the platform works.',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime)
    });
    
    // Reply from admin
    messages.push({
      id: `${room.id}-msg-2`,
      chatRoomId: room.id,
      senderId: room.adminId as string,
      message: 'Hello! I\'d be happy to help. What would you like to know?',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime + 1000 * 60 * 5) // 5 minutes later
    });
    
    // Question from user
    messages.push({
      id: `${room.id}-msg-3`,
      chatRoomId: room.id,
      senderId: room.userId as string,
      message: 'How do I update my profile information?',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime + 1000 * 60 * 10) // 10 minutes later
    });
    
    // Information from admin
    messages.push({
      id: `${room.id}-msg-4`,
      chatRoomId: room.id,
      senderId: room.adminId as string,
      message: 'You can update your profile by clicking on the profile icon in the top right corner, then selecting "Edit Profile".',
      isRead: true,
      status: 'Seen',
      sentAt: new Date(baseTime + 1000 * 60 * 15) // 15 minutes later
    });
    
    // Last message
    if (room.lastMessage) {
      messages.push({
        id: room.lastMessage.id,
        chatRoomId: room.id,
        senderId: room.lastMessage.senderId,
        message: room.lastMessage.message,
        isRead: room.lastMessage.isRead,
        status: room.lastMessage.status,
        sentAt: room.lastMessage.sentAt
      });
    }
  }
  
  return messages.sort((a, b) => a.sentAt.getTime() - b.sentAt.getTime());
};

// Backend API placeholders
export const apiEndpoints = {
  // Authentication
  login: {
    url: '/api/auth/login',
    method: 'POST',
    description: 'Authenticate user and get token'
  },
  register: {
    url: '/api/auth/register',
    method: 'POST',
    description: 'Register a new user'
  },
  
  // Chat rooms
  getChatRooms: {
    url: '/api/chat/rooms',
    method: 'GET',
    description: 'Get all chat rooms for the current user'
  },
  createChatRoom: {
    url: '/api/chat/rooms',
    method: 'POST',
    description: 'Create a new chat room'
  },
  
  // Messages
  getMessages: {
    url: '/api/chat/rooms/:roomId/messages',
    method: 'GET',
    description: 'Get all messages for a specific chat room'
  },
  sendMessage: {
    url: '/api/chat/rooms/:roomId/messages',
    method: 'POST',
    description: 'Send a new message in a chat room'
  },
  updateMessageStatus: {
    url: '/api/chat/messages/:messageId/status',
    method: 'PUT',
    description: 'Update the status of a message (Sent, Delivered, Seen)'
  },
  
  // Users
  getUser: {
    url: '/api/users/:userId',
    method: 'GET',
    description: 'Get user details'
  },
  updateUser: {
    url: '/api/users/:userId',
    method: 'PUT',
    description: 'Update user details'
  }
};