import React from 'react';
import { useAuth } from './context/AuthContext';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';

const AppRouter: React.FC = () => {
  const { currentUser } = useAuth();
  
  return (
    <div>
      {currentUser ? <Dashboard /> : <Login />}
    </div>
  );
};

export default AppRouter;