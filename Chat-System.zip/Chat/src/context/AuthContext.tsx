import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User, UserRole } from '../types';

interface AuthContextType {
  currentUser: User | null;
  login: (role: UserRole) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const dummyUsers: Record<UserRole, User> = {
  'Buyer': { id: 'buyer-1', name: 'John Buyer', role: 'Buyer' },
  'Seller': { id: 'seller-1', name: 'Mary Seller', role: 'Seller' },
  'Car Owner': { id: 'owner-1', name: 'David Owner', role: 'Car Owner' },
  'Service Provider': { id: 'provider-1', name: 'Sarah Provider', role: 'Service Provider' },
  'Admin': { id: 'admin-1', name: 'Admin User', role: 'Admin' }
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const login = (role: UserRole) => {
    setCurrentUser(dummyUsers[role]);
  };

  const logout = () => {
    setCurrentUser(null);
  };

  return (
    <AuthContext.Provider value={{ currentUser, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};