import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { ChatRoom, ChatMessage, User, MessageStatus } from '../types';
import { useAuth } from './AuthContext';
import { generateDummyChatRooms, generateDummyMessages } from '../data/dummyData';

interface ChatContextType {
  chatRooms: ChatRoom[];
  activeRoom: ChatRoom | null;
  messages: ChatMessage[];
  setActiveRoom: (room: ChatRoom | null) => void;
  sendMessage: (message: string) => void;
  updateMessageStatus: (messageId: string, status: MessageStatus) => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [activeRoom, setActiveRoom] = useState<ChatRoom | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  // Load dummy chat rooms when user changes
  useEffect(() => {
    if (currentUser) {
      const rooms = generateDummyChatRooms(currentUser);
      setChatRooms(rooms);
    } else {
      setChatRooms([]);
      setActiveRoom(null);
    }
  }, [currentUser]);

  // Load messages when active room changes
  useEffect(() => {
    if (activeRoom) {
      const roomMessages = generateDummyMessages(activeRoom, currentUser as User);
      setMessages(roomMessages);
      
      // Mark all undelivered messages as delivered
      const updatedMessages = roomMessages.map(msg => {
        if (msg.senderId !== currentUser?.id && msg.status === 'Sent') {
          return { ...msg, status: 'Delivered' };
        }
        return msg;
      });
      setMessages(updatedMessages);
      
      // Update unread count in chat rooms
      setChatRooms(prev => 
        prev.map(room => 
          room.id === activeRoom.id ? { ...room, unreadCount: 0 } : room
        )
      );
    } else {
      setMessages([]);
    }
  }, [activeRoom, currentUser]);
  
  const sendMessage = (message: string) => {
    if (!activeRoom || !currentUser) return;
    
    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      chatRoomId: activeRoom.id,
      senderId: currentUser.id,
      message,
      isRead: false,
      status: 'Sent',
      sentAt: new Date()
    };
    
    setMessages(prev => [...prev, newMessage]);
    
    // Simulate message delivery after 1 second
    setTimeout(() => {
      updateMessageStatus(newMessage.id, 'Delivered');
    }, 1000);
    
    // Update chat room with last message
    setChatRooms(prev => 
      prev.map(room => 
        room.id === activeRoom.id ? 
        { 
          ...room, 
          lastMessage: newMessage,
          updatedAt: new Date()
        } : room
      )
    );
  };
  
  const updateMessageStatus = (messageId: string, status: MessageStatus) => {
    setMessages(prev => 
      prev.map(msg => 
        msg.id === messageId ? { ...msg, status, isRead: status === 'Seen' } : msg
      )
    );
    
    // If message is in active room, update last message status
    if (activeRoom) {
      setChatRooms(prev => 
        prev.map(room => {
          if (room.id === activeRoom.id && room.lastMessage?.id === messageId) {
            return {
              ...room,
              lastMessage: {
                ...room.lastMessage,
                status,
                isRead: status === 'Seen'
              }
            };
          }
          return room;
        })
      );
    }
  };

  return (
    <ChatContext.Provider value={{ 
      chatRooms, 
      activeRoom, 
      messages, 
      setActiveRoom, 
      sendMessage,
      updateMessageStatus
    }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = (): ChatContextType => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};