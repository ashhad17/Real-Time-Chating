import React from 'react';
import { useAuth } from '../context/AuthContext';
import FloatingChatButton from '../components/chat/FloatingChatButton';

const Dashboard: React.FC = () => {
  const { currentUser, logout } = useAuth();
  
  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-sm font-medium text-gray-900">{currentUser.name}</p>
              <p className="text-xs text-gray-500">{currentUser.role}</p>
            </div>
            <img 
              src={`https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}&background=random`} 
              alt={currentUser.name}
              className="h-10 w-10 rounded-full"
            />
            <button 
              onClick={logout}
              className="ml-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded"
            >
              Logout
            </button>
          </div>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Welcome, {currentUser.name}</h2>
            
            <div className="mt-4 bg-gray-50 p-4 rounded-md">
              <h3 className="font-medium text-gray-800 mb-2">Your Role: {currentUser.role}</h3>
              <p className="text-gray-600 mb-4">
                This is a dummy dashboard. The main feature is the chat system available via the floating button in the bottom right corner.
              </p>
              
              {currentUser.role === 'Buyer' && (
                <p className="text-gray-600">
                  As a Buyer, you can communicate with Sellers about their listings and contact Admin support.
                </p>
              )}
              
              {currentUser.role === 'Seller' && (
                <p className="text-gray-600">
                  As a Seller, you can communicate with potential Buyers about your listings and contact Admin support.
                </p>
              )}
              
              {currentUser.role === 'Car Owner' && (
                <p className="text-gray-600">
                  As a Car Owner, you can communicate with Service Providers about appointments and contact Admin support.
                </p>
              )}
              
              {currentUser.role === 'Service Provider' && (
                <p className="text-gray-600">
                  As a Service Provider, you can communicate with Car Owners about service appointments and contact Admin support.
                </p>
              )}
              
              {currentUser.role === 'Admin' && (
                <p className="text-gray-600">
                  As an Admin, you can communicate with all users on the platform to provide support.
                </p>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <FloatingChatButton />
    </div>
  );
};

export default Dashboard;