import React from 'react';
import { useAuth } from '../context/AuthContext';
import ChatInterface from '../components/chat/ChatInterface';

const ChatPage: React.FC = () => {
  const { currentUser, logout } = useAuth();
  
  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Messages</h1>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-sm font-medium text-gray-900">{currentUser.name}</p>
              <p className="text-xs text-gray-500">{currentUser.role}</p>
            </div>
            <img 
              src={`https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}&background=random`} 
              alt={currentUser.name}
              className="h-10 w-10 rounded-full"
            />
            <button 
              onClick={logout}
              className="ml-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded"
            >
              Logout
            </button>
          </div>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white overflow-hidden shadow rounded-lg h-[calc(100vh-8rem)]">
          <ChatInterface />
        </div>
      </main>
    </div>
  );
};

export default ChatPage;