export type UserRole = 'Buyer' | 'Seller' | 'Car Owner' | 'Service Provider' | 'Admin';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  avatar?: string;
}

export type ChatRoomType = 'BuyerSeller' | 'OwnerProvider' | 'UserAdmin';

export interface ChatRoom {
  id: string;
  type: ChatRoomType;
  buyerId?: string;
  sellerId?: string;
  ownerId?: string;
  providerId?: string;
  adminId?: string;
  userId?: string;
  listingId?: string;
  appointmentId?: string;
  lastMessage?: ChatMessage;
  unreadCount: number;
  updatedAt: Date;
  otherUser: User;
}

export type MessageStatus = 'Sent' | 'Delivered' | 'Seen';

export interface ChatMessage {
  id: string;
  chatRoomId: string;
  senderId: string;
  message: string;
  isRead: boolean;
  status: MessageStatus;
  sentAt: Date;
}