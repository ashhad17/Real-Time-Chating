import { ChatMessage, ChatRoom, User, MessageStatus } from '../types';

/**
 * API Endpoint Documentation
 * This file serves as a reference for the backend API endpoints that will be implemented.
 */

export const API_BASE_URL = '/api';

export const endpoints = {
  auth: {
    /**
     * Authenticate user and get access token
     * POST /api/auth/login
     * @body { email: string, password: string }
     * @returns { token: string, user: User }
     */
    login: `${API_BASE_URL}/auth/login`,

    /**
     * Register a new user
     * POST /api/auth/register
     * @body { email: string, password: string, name: string, role: UserRole }
     * @returns { token: string, user: User }
     */
    register: `${API_BASE_URL}/auth/register`,

    /**
     * Get current user profile
     * GET /api/auth/me
     * @returns { user: User }
     */
    profile: `${API_BASE_URL}/auth/me`,
  },

  chat: {
    /**
     * Get all chat rooms for the current user
     * GET /api/chat/rooms
     * @returns { rooms: ChatRoom[] }
     */
    getRooms: `${API_BASE_URL}/chat/rooms`,

    /**
     * Create a new chat room
     * POST /api/chat/rooms
     * @body { type: ChatRoomType, participantId: string }
     * @returns { room: ChatRoom }
     */
    createRoom: `${API_BASE_URL}/chat/rooms`,

    /**
     * Get messages for a specific chat room
     * GET /api/chat/rooms/:roomId/messages
     * @param roomId - The ID of the chat room
     * @returns { messages: ChatMessage[] }
     */
    getMessages: (roomId: string) => `${API_BASE_URL}/chat/rooms/${roomId}/messages`,

    /**
     * Send a new message in a chat room
     * POST /api/chat/rooms/:roomId/messages
     * @param roomId - The ID of the chat room
     * @body { message: string }
     * @returns { message: ChatMessage }
     */
    sendMessage: (roomId: string) => `${API_BASE_URL}/chat/rooms/${roomId}/messages`,

    /**
     * Update message status (Sent, Delivered, Seen)
     * PUT /api/chat/messages/:messageId/status
     * @param messageId - The ID of the message
     * @body { status: MessageStatus }
     * @returns { success: boolean }
     */
    updateMessageStatus: (messageId: string) => `${API_BASE_URL}/chat/messages/${messageId}/status`,

    /**
     * Mark all messages in a room as read
     * PUT /api/chat/rooms/:roomId/read
     * @param roomId - The ID of the chat room
     * @returns { success: boolean }
     */
    markRoomAsRead: (roomId: string) => `${API_BASE_URL}/chat/rooms/${roomId}/read`,
  },

  users: {
    /**
     * Get user details
     * GET /api/users/:userId
     * @param userId - The ID of the user
     * @returns { user: User }
     */
    getUser: (userId: string) => `${API_BASE_URL}/users/${userId}`,

    /**
     * Update user profile
     * PUT /api/users/:userId
     * @param userId - The ID of the user
     * @body { name: string, avatar: string }
     * @returns { user: User }
     */
    updateUser: (userId: string) => `${API_BASE_URL}/users/${userId}`,

    /**
     * Search users by role
     * GET /api/users/search
     * @query role - Filter users by role
     * @returns { users: User[] }
     */
    searchUsers: `${API_BASE_URL}/users/search`,
  },
};

// Example usage of the API endpoints
export const apiClient = {
  async login(email: string, password: string) {
    const response = await fetch(endpoints.auth.login, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    return response.json();
  },

  async getChatRooms() {
    const response = await fetch(endpoints.chat.getRooms, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
    return response.json();
  },

  async sendMessage(roomId: string, message: string) {
    const response = await fetch(endpoints.chat.sendMessage(roomId), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({ message }),
    });
    return response.json();
  },

  async updateMessageStatus(messageId: string, status: MessageStatus) {
    const response = await fetch(endpoints.chat.updateMessageStatus(messageId), {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({ status }),
    });
    return response.json();
  },
};

export default endpoints;