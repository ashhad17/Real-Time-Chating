import React from 'react';
import { MessageStatus } from '../../types';
import { Check, CheckCheck, Mail, Eye } from 'lucide-react';

interface MessageStatusIconProps {
  status: MessageStatus;
  size?: number;
}

export const MessageStatusIcon: React.FC<MessageStatusIconProps> = ({ status, size = 16 }) => {
  const className = `text-gray-500`;

  switch (status) {
    case 'Sent':
      return <Mail size={size} className={className} />;
    case 'Delivered':
      return <Check size={size} className={className} />;
    case 'Seen':
      return <Eye size={size} className={className} />;
    default:
      return null;
  }
};