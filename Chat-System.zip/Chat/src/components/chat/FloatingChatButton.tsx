import React, { useState } from 'react';
import { MessageSquare, X } from 'lucide-react';
import ChatInterface from './ChatInterface';
import { useAuth } from '../../context/AuthContext';

const FloatingChatButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { currentUser } = useAuth();
  
  const toggleChat = () => {
    setIsOpen(!isOpen);
  };
  
  if (!currentUser) return null;
  
  return (
    <>
      {/* Chat modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 md:flex md:items-center md:justify-center bg-black bg-opacity-50">
          <div className="fixed inset-0 md:relative md:w-full md:max-w-5xl md:h-[40rem] bg-white md:rounded-lg md:shadow-xl flex flex-col overflow-hidden">
            <div className="flex items-center justify-between border-b border-gray-200 p-4">
              <h2 className="text-lg font-semibold text-gray-800">
                My Messages
              </h2>
              <button
                onClick={toggleChat}
                className="text-gray-500 hover:text-gray-700 focus:outline-none"
              >
                <X size={24} />
              </button>
            </div>
            <div className="flex-1 overflow-hidden">
              <ChatInterface />
            </div>
          </div>
        </div>
      )}
      
      {/* Floating button */}
      <button
        onClick={toggleChat}
        className="fixed bottom-6 right-6 z-40 bg-blue-600 hover:bg-blue-700 text-white rounded-full p-4 shadow-lg transition-all duration-300 ease-in-out flex items-center justify-center"
      >
        <MessageSquare size={24} />
      </button>
    </>
  );
};

export default FloatingChatButton;