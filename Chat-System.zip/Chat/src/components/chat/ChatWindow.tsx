import React, { useState, useRef, useEffect } from 'react';
import { useChat } from '../../context/ChatContext';
import { useAuth } from '../../context/AuthContext';
import { formatMessageTime } from '../../utils/dateUtils';
import { MessageStatusIcon } from './MessageStatusIcon';
import { Send } from 'lucide-react';

const ChatWindow: React.FC = () => {
  const { activeRoom, messages, sendMessage, updateMessageStatus } = useChat();
  const { currentUser } = useAuth();
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  useEffect(() => {
    if (activeRoom && messages.length > 0) {
      messages.forEach(msg => {
        if (msg.senderId !== currentUser?.id && msg.status !== 'Seen') {
          updateMessageStatus(msg.id, 'Seen');
        }
      });
    }
  }, [activeRoom, messages, currentUser, updateMessageStatus]);
  
  const handleSendMessage = () => {
    if (newMessage.trim() && activeRoom) {
      sendMessage(newMessage.trim());
      setNewMessage('');
    }
  };
  
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  if (!activeRoom) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-50 p-4">
        <div className="text-center">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Select a conversation</h3>
          <p className="text-gray-500">Choose a chat from the list to start messaging</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="h-full flex flex-col">
      {/* Chat header */}
      <div className="px-6 py-4 border-b border-gray-200 flex items-center bg-white">
        <img 
          src={activeRoom.otherUser.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(activeRoom.otherUser.name)}&background=random`} 
          alt={activeRoom.otherUser.name}
          className="w-10 h-10 rounded-full object-cover"
        />
        <div className="ml-3">
          <h2 className="text-lg font-semibold text-gray-900">{activeRoom.otherUser.name}</h2>
          <p className="text-xs text-gray-500">{activeRoom.otherUser.role}</p>
        </div>
      </div>
      
      {/* Messages */}
      <div 
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto p-4 bg-gray-50"
        style={{ height: 'calc(100% - 140px)' }}
      >
        <div className="space-y-4">
          {messages.map((msg) => {
            const isOwnMessage = msg.senderId === currentUser?.id;
            
            return (
              <div 
                key={msg.id} 
                className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                    isOwnMessage 
                      ? 'bg-blue-600 text-white rounded-br-none' 
                      : 'bg-gray-200 text-gray-800 rounded-bl-none'
                  }`}
                >
                  <p className="text-sm">{msg.message}</p>
                  <div className={`flex items-center mt-1 text-xs ${isOwnMessage ? 'text-blue-200 justify-end' : 'text-gray-500'}`}>
                    <span>{formatMessageTime(msg.sentAt)}</span>
                    {isOwnMessage && (
                      <span className="ml-1">
                        <MessageStatusIcon status={msg.status} size={16} />
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      {/* Message input */}
      <div className="p-4 border-t border-gray-200 bg-white">
        <div className="flex items-center bg-gray-100 rounded-lg px-3 py-2">
          <textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="Type a message..."
            className="flex-1 bg-transparent border-0 focus:ring-0 text-gray-800 resize-none outline-none h-10 max-h-32 py-2"
            rows={1}
          />
          <button
            onClick={handleSendMessage}
            disabled={!newMessage.trim()}
            className={`ml-2 p-2 rounded-full ${
              newMessage.trim() 
                ? 'bg-blue-600 text-white hover:bg-blue-700' 
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            } transition-colors`}
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;