import React, { useState } from 'react';
import ChatList from './ChatList';
import ChatWindow from './ChatWindow';
import { useChat } from '../../context/ChatContext';
import { ArrowLeft } from 'lucide-react';

const ChatInterface: React.FC = () => {
  const { activeRoom, setActiveRoom } = useChat();
  const [showMobileChat, setShowMobileChat] = useState(false);

  const handleBackToList = () => {
    setShowMobileChat(false);
    setActiveRoom(null);
  };

  return (
    <div className="h-full flex overflow-hidden bg-white md:rounded-lg">
      <div className={`w-full md:w-80 lg:w-96 h-full flex-shrink-0 ${showMobileChat ? 'hidden md:block' : 'block'}`}>
        <ChatList onChatSelect={() => setShowMobileChat(true)} />
      </div>
      
      <div className={`w-full h-full ${!showMobileChat ? 'hidden md:block' : 'block'}`}>
        {activeRoom && (
          <div className="h-full flex flex-col">
            <div className="md:hidden flex items-center px-4 py-2 border-b border-gray-200 bg-white">
              <button
                onClick={handleBackToList}
                className="p-2 hover:bg-gray-100 rounded-full"
              >
                <ArrowLeft size={24} />
              </button>
            </div>
            <div className="flex-1 overflow-hidden">
              <ChatWindow />
            </div>
          </div>
        )}
        
        {!activeRoom && (
          <div className="hidden md:flex h-full items-center justify-center bg-gray-50">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-gray-700 mb-2">Select a conversation</h3>
              <p className="text-gray-500">Choose a chat from the list to start messaging</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatInterface;