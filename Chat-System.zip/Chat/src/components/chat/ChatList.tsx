import React from 'react';
import { useChat } from '../../context/ChatContext';
import { formatTime } from '../../utils/dateUtils';
import { MessageStatusIcon } from './MessageStatusIcon';

interface ChatListProps {
  onChatSelect?: () => void;
}

const ChatList: React.FC<ChatListProps> = ({ onChatSelect }) => {
  const { chatRooms, activeRoom, setActiveRoom } = useChat();

  const handleChatSelect = (room: any) => {
    setActiveRoom(room);
    onChatSelect?.();
  };

  return (
    <div className="h-full flex flex-col overflow-hidden border-r border-gray-200">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800">Messages</h2>
      </div>
      
      <div className="flex-1 overflow-y-auto bg-white">
        {chatRooms.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-500">No conversations yet</p>
          </div>
        ) : (
          <ul>
            {chatRooms.map((room) => (
              <li 
                key={room.id}
                className={`border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors ${
                  activeRoom?.id === room.id ? 'bg-blue-50' : ''
                }`}
                onClick={() => handleChatSelect(room)}
              >
                <div className="flex items-center p-4">
                  <div className="relative">
                    <img 
                      src={room.otherUser.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(room.otherUser.name)}&background=random`} 
                      alt={room.otherUser.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    {room.unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 flex items-center justify-center w-5 h-5 bg-blue-600 text-white text-xs font-bold rounded-full">
                        {room.unreadCount}
                      </span>
                    )}
                  </div>
                  
                  <div className="ml-4 flex-1">
                    <div className="flex justify-between items-center">
                      <h3 className="font-semibold text-gray-900">{room.otherUser.name}</h3>
                      <span className="text-xs text-gray-500">
                        {formatTime(room.updatedAt)}
                      </span>
                    </div>
                    
                    <div className="flex items-center mt-1">
                      {room.lastMessage && (
                        <>
                          <p className={`text-sm truncate ${room.unreadCount > 0 ? 'font-semibold text-gray-900' : 'text-gray-500'}`}>
                            {room.lastMessage.senderId === room.otherUser.id ? (
                              room.lastMessage.message
                            ) : (
                              <>
                                You: {room.lastMessage.message}
                              </>
                            )}
                          </p>
                          
                          {room.lastMessage.senderId !== room.otherUser.id && (
                            <span className="ml-2">
                              <MessageStatusIcon status={room.lastMessage.status} size={16} />
                            </span>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default ChatList;