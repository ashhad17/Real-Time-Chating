## Frontend API Integration Guide

### 1. Authentication Context Changes

The `AuthContext` needs to be updated to use real authentication:

```typescript
// src/context/AuthContext.tsx
import { apiClient } from '../api/endpoints';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const login = async (email: string, password: string) => {
    try {
      const { token, user } = await apiClient.login(email, password);
      localStorage.setItem('token', token);
      setCurrentUser(user);
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  };

  // Add token check on mount
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      // Fetch user profile
      fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(data => setCurrentUser(data.user))
      .catch(() => localStorage.removeItem('token'));
    }
  }, []);
};
```

### 2. Chat Context Integration

Replace dummy data with API calls in `ChatContext`:

```typescript
// src/context/ChatContext.tsx
import { apiClient } from '../api/endpoints';

export const ChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Load chat rooms from API
  useEffect(() => {
    if (currentUser) {
      apiClient.getChatRooms()
        .then(data => setChatRooms(data.rooms))
        .catch(console.error);
    }
  }, [currentUser]);

  // Load messages when room changes
  useEffect(() => {
    if (activeRoom) {
      fetch(endpoints.chat.getMessages(activeRoom.id), {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      })
        .then(res => res.json())
        .then(data => setMessages(data.messages))
        .catch(console.error);
    }
  }, [activeRoom]);

  const sendMessage = async (message: string) => {
    if (!activeRoom || !currentUser) return;
    
    try {
      const response = await apiClient.sendMessage(activeRoom.id, message);
      setMessages(prev => [...prev, response.message]);
      
      // Update chat room with last message
      setChatRooms(prev => 
        prev.map(room => 
          room.id === activeRoom.id ? 
          { ...room, lastMessage: response.message } : room
        )
      );
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };
};
```

### 3. Real-time Updates

Implement WebSocket connection for real-time updates:

```typescript
// src/context/ChatContext.tsx
useEffect(() => {
  if (!currentUser) return;

  const ws = new WebSocket('wss://your-api-url/ws');
  
  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    
    switch (data.type) {
      case 'NEW_MESSAGE':
        handleNewMessage(data.message);
        break;
      case 'MESSAGE_STATUS':
        handleMessageStatusUpdate(data.messageId, data.status);
        break;
      case 'NEW_CHAT':
        handleNewChatRoom(data.room);
        break;
    }
  };

  return () => ws.close();
}, [currentUser]);
```

### 4. Error Handling

Add error handling and loading states:

```typescript
// src/context/ChatContext.tsx
const [isLoading, setIsLoading] = useState(false);
const [error, setError] = useState<string | null>(null);

const sendMessage = async (message: string) => {
  try {
    setIsLoading(true);
    setError(null);
    // API call here
  } catch (error) {
    setError('Failed to send message');
    // Show error to user
  } finally {
    setIsLoading(false);
  }
};
```

### 5. Component Updates

Update components to handle loading and error states:

```typescript
// src/components/chat/ChatWindow.tsx
const ChatWindow: React.FC = () => {
  const { messages, isLoading, error } = useChat();

  if (isLoading) {
    return <div>Loading messages...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  // Existing render code
};
```

### 6. Message Status Updates

Implement real message status tracking:

```typescript
// src/components/chat/ChatWindow.tsx
useEffect(() => {
  if (activeRoom && messages.length > 0) {
    // Mark messages as seen
    const unseenMessages = messages.filter(
      msg => msg.senderId !== currentUser?.id && msg.status !== 'Seen'
    );
    
    if (unseenMessages.length > 0) {
      fetch(endpoints.chat.markRoomAsRead(activeRoom.id), {
        method: 'PUT',
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
    }
  }
}, [activeRoom, messages]);
```

### 7. Token Management

Add an interceptor for API calls to handle token:

```typescript
// src/api/interceptor.ts
const apiInterceptor = async (url: string, options: RequestInit = {}) => {
  const token = localStorage.getItem('token');
  
  const response = await fetch(url, {
    ...options,
    headers: {
      ...options.headers,
      Authorization: token ? `Bearer ${token}` : '',
    },
  });

  if (response.status === 401) {
    localStorage.removeItem('token');
    window.location.href = '/login';
    return;
  }

  return response;
};
```

### Implementation Steps

1. Remove all dummy data from `src/data/dummyData.ts`
2. Update contexts to use real API calls
3. Add loading and error states
4. Implement WebSocket connection
5. Add token management
6. Update components to handle async operations
7. Add error boundaries for error handling

### Security Considerations

1. Always use HTTPS for API calls
2. Store token securely
3. Validate data from API
4. Implement proper error handling
5. Add request timeouts
6. Handle token expiration